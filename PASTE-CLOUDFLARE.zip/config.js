// Connects the site to its own backend (Cloudflare).
window.PASTE_API = location.origin;
