// Paste API: one Supabase Edge Function. Deploy it with the name "api" and "Verify JWT" turned OFF.

const MAX_PASTE = 512 * 1024;
const TTL = { never: null, '10m': 600000, '1h': 3600000, '1d': 86400000, '1w': 604800000 };
const SYN = ['none', 'javascript', 'typescript', 'python', 'html', 'css', 'json', 'bash', 'sql', 'php', 'java', 'c', 'cpp', 'csharp', 'go', 'rust', 'ruby', 'markdown', 'yaml', 'xml'];
const TIERS = [[0, 'ROOKIE'], [15, 'MEMBER'], [60, 'PRO'], [200, 'ELITE']];
const VIEW_TIERS = [[10000, 'VIP', 'vip'], [25000, 'VIP+', 'vipplus'], [100000, '⭐', 'star']];
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const NAME_RE = /^[\p{L}\p{N} ._-]{2,24}$/u;
const SESSION_MS = 30 * 86400000;
const LIVE = '(p.expires_at is null or p.expires_at > $1)';

const enc = (t) => new TextEncoder().encode(t);
const hex = (buf) => Array.from(new Uint8Array(buf)).map((x) => x.toString(16).padStart(2, '0')).join('');
const unhex = (h) => new Uint8Array((h.match(/../g) || []).map((x) => parseInt(x, 16)));
const randHex = (n) => hex(crypto.getRandomValues(new Uint8Array(n)));
const ALPHA = 'abcdefghijklmnopqrstuvwxyz0123456789';
const rid = (n = 8) => Array.from(crypto.getRandomValues(new Uint8Array(n)), (b) => ALPHA[b % 36]).join('');
const sha256 = async (t) => hex(await crypto.subtle.digest('SHA-256', enc(t)));
let ITER = 100000;
async function pbkdf2(password, saltHex) {
  const key = await crypto.subtle.importKey('raw', enc(password), 'PBKDF2', false, ['deriveBits']);
  return hex(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: unhex(saltHex), iterations: ITER }, key, 256));
}
const same = (a, b) => { if (a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0; };

function httpsUrl(v) {
  v = String(v == null ? '' : v).trim(); if (!v) return '';
  if (v.length > 300) return null;
  const h = /^https:\/\//i.test(v) ? v : (/^[a-z][a-z0-9+.-]*:/i.test(v) ? null : 'https://' + v);
  if (!h) return null;
  try {
    const x = new URL(h); if (x.protocol !== 'https:' || x.username || x.password) return null;
    const host = x.hostname;
    if (host === 'localhost' || /^[\d.]+$/.test(host) || host.indexOf('[') >= 0 || /\.(local|internal)$/.test(host) || host.indexOf('.') < 0) return null;
    return x.href;
  } catch (e) { return null; }
}

function rankOf(s) {
  const pastes = s.pastes || 0, views = s.views || 0, likes = s.likes || 0;
  const score = pastes * 3 + Math.floor(views / 5) + likes * 5, base = { score, views };
  let vt = -1, t = 0;
  VIEW_TIERS.forEach((r, i) => { if (views >= r[0]) vt = i; });
  if (vt >= 0) { const vn = VIEW_TIERS[vt + 1]; return { ...base, label: VIEW_TIERS[vt][1], tier: VIEW_TIERS[vt][2], from: VIEW_TIERS[vt][0], value: views, next: vn ? { label: vn[1], at: vn[0], unit: 'views' } : null }; }
  TIERS.forEach((r, i) => { if (score >= r[0]) t = i; });
  if (t < TIERS.length - 1) { const nx = TIERS[t + 1]; return { ...base, label: TIERS[t][1], tier: t, from: TIERS[t][0], value: score, next: { label: nx[1], at: nx[0], unit: 'points' } }; }
  return { ...base, label: TIERS[t][1], tier: t, from: 0, value: views, next: { label: VIEW_TIERS[0][1], at: VIEW_TIERS[0][0], unit: 'views' } };
}
/* Chat safety filter: blocks sexual content, slurs, harassment and links. Same code runs in the server and the preview. */
const CHAT_SUB = ['fuck', 'motherfuck', 'bitch', 'nigg', 'faggot', 'fagg', 'whore', 'slut', 'porn', 'pussy', 'blowjob', 'handjob', 'cumshot', 'dildo', 'jerkoff', 'jackoff', 'masturbat', 'orgasm', 'erotic', 'hentai', 'cocksuck', 'dicksuck', 'titties', 'boobies', 'nudes', 'sexting', 'onlyfans', 'tranny', 'wetback', 'beaner', 'molest', 'killyourself', 'killurself', 'hangyourself', 'nsfw', 'fvck', 'fuk', 'phuck', 'fck'];
const CHAT_WORD = ['chink', 'spic', 'kike', 'coon', 'paki', 'pedo', 'pedophile', 'kys', 'rapist', 'xxx', 'gook', 'fuk', 'fck', 'sex', 'sexy', 'sext', 'nude', 'naked', 'cum', 'cumming', 'dick', 'cock', 'penis', 'vagina', 'tit', 'tits', 'boob', 'boobs', 'ass', 'asshole', 'arse', 'anal', 'cunt', 'shit', 'bullshit', 'rape', 'raped', 'horny', 'milf', 'incest', 'fap', 'wank', 'retard', 'retarded', 'nazi', 'hitler', 'bastard', 'damn', 'piss', 'prick', 'twat', 'negro', 'nig', 'fag', 'dyke', 'hoe', 'thot', 'suck', 'lick', 'bdsm', 'fetish', 'strip', 'stripper', 'escort', 'hooker', 'erection', 'semen', 'sperm', 'clit', 'vulva', 'testicle', 'balls', 'nipple', 'nipples', 'creampie', 'gangbang', 'threesome', 'orgy'];
const CHAT_LEET = { '0': 'o', '1': 'i', '3': 'e', '4': 'a', '5': 's', '7': 't', '8': 'b', '9': 'g', '@': 'a', '$': 's', '!': 'i', '|': 'i', '+': 't', '€': 'e', '£': 'l' };
const chatNorm = (t) => String(t).normalize('NFKD').replace(/[̀-ͯ​-‏⁠﻿]/g, '').toLowerCase().replace(/[01345789@$!|+€£]/g, (c) => CHAT_LEET[c] || c);
const chatSquash = (s) => s.replace(/(.)\1{1,}/g, '$1');
const chatStem = (w) => w.replace(/(ing|ers|er|ed|es|s|y)$/, '');
function chatBad(text) {
  const n = chatNorm(text);
  const compact = n.replace(/[^a-z]/g, '');
  const sq = chatSquash(compact);
  for (const w of CHAT_SUB) { const ws = chatSquash(w); if (compact.includes(w) || (ws.length >= 4 && sq.includes(ws))) return 'language'; }
  const words = n.split(/[^a-z]+/).filter(Boolean);
  const set = new Set(CHAT_WORD);
  for (const raw of words) {
    for (const w of [raw, chatSquash(raw)]) { if (set.has(w) || set.has(chatStem(w))) return 'language'; }
  }
  // spaced-out letters like "f u c k" or "s.e.x"
  const runs = n.match(/(?:\b[a-z][^a-z0-9]{1,2}){2,}[a-z]\b/g) || [];
  for (const r of runs) { const c = chatSquash(r.replace(/[^a-z]/g, '')); if (CHAT_SUB.some((w) => chatSquash(w).length >= 4 && c.includes(chatSquash(w))) || set.has(c)) return 'language'; }
  return '';
}
function chatLink(text) {
  const t = String(text).toLowerCase();
  return /https?:|www\.|t\.me|discord\.gg|\.(com|net|org|io|me|gg|ly|xyz|ru|tk|cc|co|app|site|shop|link|to)\b/.test(t.replace(/\s+\.\s+/g, '.')) || /\b[a-z0-9-]+\s*(\.|dot)\s*(com|net|org|io|gg|xyz|ru|shop)\b/.test(t);
}
function chatCheck(text) {
  const s = String(text == null ? '' : text).replace(/\s+/g, ' ').trim();
  if (!s) return { error: 'Type a message first.' };
  if (s.length > 300) return { error: 'Messages can be up to 300 characters.' };
  if (chatLink(s)) return { error: 'Links are not allowed in chat.' };
  if (chatBad(s)) return { error: 'Message blocked: keep chat clean (no sexual content, slurs or insults).' };
  if (/(.)\1{9,}/.test(s) || (s.length > 12 && s === s.toUpperCase() && /[A-Z]{12,}/.test(s))) return { error: 'Please do not spam or shout.' };
  return { text: s };
}

const brief = (r) => ({ label: r.label, tier: r.tier });

export async function handle(req, ctx) {
  const env = ctx.env || {}, q = ctx.q, doFetch = ctx.fetch || fetch; if (ctx.iterations) ITER = ctx.iterations;
  const CORS = {
    'Access-Control-Allow-Origin': env.ALLOWED_ORIGIN || '*',
    'Access-Control-Allow-Headers': 'authorization, content-type, x-client-info, apikey',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Access-Control-Max-Age': '86400'
  };
  const reply = (code, obj) => new Response(JSON.stringify(obj), { status: code, headers: { ...CORS, 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });

  try {
    const url = new URL(req.url);
    // On Supabase the function is served under /functions/v1/api, and the site then calls /api/... below that.
    const rawPath = url.pathname; const apiAt = rawPath.indexOf('/api/'); const path = (apiAt >= 0 ? rawPath.slice(apiAt) : rawPath).replace(/^\/api\/api\//, '/api/');
    const method = req.method;
    const now = Date.now();
    const ip = (req.headers.get('x-forwarded-for') || '').split(',')[0].trim() || 'unknown';

    const limited = async (kind, max, windowMs) => {
      const k = kind + ':' + ip;
      await q('delete from rate_events where t < $1', [now - 3600000]);
      const r = await q('select count(*)::int c from rate_events where k = $1 and t > $2', [k, now - windowMs]);
      if (r[0].c >= max) return true;
      await q('insert into rate_events (k, t) values ($1, $2)', [k, now]);
      return false;
    };
    const bearer = () => { const h = req.headers.get('authorization') || ''; const m = /^Bearer\s+([A-Za-z0-9]{20,100})$/.exec(h); return m ? m[1] : ''; };
    let meCache; const me = async () => {
      if (meCache !== undefined) return meCache;
      const t = bearer(); if (!t) return (meCache = null);
      const r = await q('select u.* from sessions s join users u on u.id = s.user_id where s.token_hash = $1 and s.expires_at > $2', [await sha256(t), now]);
      return (meCache = r[0] || null);
    };
    const body = async () => {
      const t = await req.text();
      if (t.length > 1200000) throw Object.assign(new Error('Request too large.'), { code: 413 });
      try { return JSON.parse(t || '{}') || {}; } catch (e) { throw Object.assign(new Error('Invalid request.'), { code: 400 }); }
    };
    const profileOf = (u) => ({ avatar: u.avatar || '', cover: u.cover || '', bio: u.bio || '', telegram: u.telegram || '', discord: u.discord || '', website: u.website || '' });
    const inList = (start, arr) => arr.map((_, i) => '$' + (start + i)).join(',');
    const ranks = async (names) => {
      const ks = [...new Set(names.filter(Boolean).map((n) => String(n).toLowerCase()))];
      const out = {}; ks.forEach((k) => { out[k] = rankOf({}); });
      if (!ks.length) return out;
      const rows = await q(`select lower(p.author) a, count(*)::int pastes, coalesce(sum(p.views), 0)::int views,
          coalesce(sum((select count(*) from votes v where v.paste_id = p.id and v.v = 1)), 0)::int likes
        from pastes p where p.visibility = 'public' and p.author <> '' and ${LIVE} and lower(p.author) in (${inList(2, ks)})
        group by lower(p.author)`, [now, ...ks]);
      rows.forEach((r) => { out[r.a] = rankOf(r); });
      return out;
    };
    const pubUser = async (u) => { const rk = await ranks([u.name]); return { owner: true, name: u.name, email: u.email, joined: u.joined || 0, profile: profileOf(u), rank: rk[u.name.toLowerCase()] }; };
    const LIST_COLS = `p.id, p.title, p.syntax, p.created_at, p.views, p.size, p.author, p.pinned,
      coalesce((select u.avatar from users u where lower(u.name) = lower(p.author)), '') avatar,
      (select count(*) from votes v where v.paste_id = p.id and v.v = 1)::int up,
      (select count(*) from votes v where v.paste_id = p.id and v.v = -1)::int down`;
    const summarize = async (rows) => {
      const rk = await ranks(rows.map((r) => r.author));
      return rows.map((r) => ({ id: r.id, title: r.title, syntax: r.syntax, createdAt: r.created_at, views: r.views, size: r.size, author: r.author || '', avatar: r.avatar || '', pinned: !!r.pinned, rank: r.author ? brief(rk[r.author.toLowerCase()]) : null, up: r.up, down: r.down }));
    };
    const newSession = async (uid) => {
      const tok = randHex(32);
      await q('delete from sessions where expires_at < $1', [now]);
      await q('insert into sessions (token_hash, user_id, created_at, expires_at) values ($1, $2, $3, $4)', [await sha256(tok), uid, now, now + SESSION_MS]);
      return tok;
    };
    const siteBase = () => (env.SITE_URL || req.headers.get('origin') || '').replace(/\/+$/, '');
    const sendMail = async (to, subject, text) => {
      if (!env.RESEND_API_KEY) return false;
      try {
        const r = await doFetch('https://api.resend.com/emails', { method: 'POST', headers: { Authorization: 'Bearer ' + env.RESEND_API_KEY, 'Content-Type': 'application/json' },
          body: JSON.stringify({ from: env.MAIL_FROM || 'Paste <onboarding@resend.dev>', to: [to], subject, text }) });
        return r.ok;
      } catch (e) { return false; }
    };
    const PWERR = 'Password must be 8 to 200 characters.';

    if (method === 'GET' && (path === '/api/health' || /\/health\/?$/.test(rawPath))) return reply(200, { ok: true, v: 'v3' });

    if (method === 'POST' && path === '/api/paste') {
      if (await limited('paste', 10, 60000)) return reply(429, { error: 'Too many pastes. Wait a minute and try again.' });
      const d = await body();
      const content = typeof d.content === 'string' ? d.content : '';
      if (!content.trim()) return reply(400, { error: 'Paste is empty.' });
      const size = enc(content).length;
      if (size > MAX_PASTE) return reply(413, { error: 'Paste is too large (max 512 KB).' });
      const title = (typeof d.title === 'string' ? d.title : '').trim().slice(0, 100) || 'Untitled';
      const u = await me();
      const syntax = SYN.indexOf(d.syntax) >= 0 ? d.syntax : 'none';
      const vis = d.visibility === 'unlisted' ? 'unlisted' : 'public';
      const ttl = Object.prototype.hasOwnProperty.call(TTL, d.expires) ? TTL[d.expires] : null;
      let salt = null, hash = null; const typedPw = typeof d.password === 'string' ? d.password : '';
      if (typedPw) {
        if (vis !== 'unlisted') return reply(400, { error: 'A password only works on unlisted pastes.' });
        if (typedPw.length < 4 || typedPw.length > 100) return reply(400, { error: 'Password must be 4 to 100 characters.' });
        salt = randHex(16); hash = await pbkdf2(typedPw, salt);
      }
      await q('delete from pastes p where p.expires_at is not null and p.expires_at < $1', [now]);
      for (let i = 0; i < 6; i++) {
        const id = rid();
        const r = await q(`insert into pastes (id, title, author, owner, content, syntax, visibility, size, created_at, expires_at, pw_salt, pw_hash)
          values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) on conflict (id) do nothing returning id`,
        [id, title, u ? u.name : '', u ? u.id : null, content, syntax, vis, size, now, ttl ? now + ttl : null, salt, hash]);
        if (r.length) return reply(201, { id });
      }
      return reply(500, { error: 'Could not save the paste. Try again.' });
    }

    if (method === 'POST' && path === '/api/register') {
      if (await limited('auth', 10, 60000)) return reply(429, { error: 'Too many attempts. Wait a minute and try again.' });
      const d = await body();
      const email = String(d.email || '').trim().toLowerCase(), name = String(d.name || '').trim(), pw = typeof d.password === 'string' ? d.password : '';
      if (email.length > 254 || !EMAIL_RE.test(email)) return reply(400, { error: 'Enter a valid email address.' });
      if (!NAME_RE.test(name)) return reply(400, { error: 'Display name must be 2 to 24 letters, numbers, spaces, dots, dashes or underscores.' });
      if (pw.length < 8 || pw.length > 200) return reply(400, { error: PWERR });
      if ((await q('select 1 from users where email = $1', [email])).length) return reply(409, { error: 'That email is already registered. Try signing in.' });
      if ((await q('select 1 from users where lower(name) = lower($1)', [name])).length) return reply(409, { error: 'That display name is taken. Pick another.' });
      const salt = randHex(16), hash = await pbkdf2(pw, salt);
      let row;
      try { row = (await q('insert into users (email, name, pw_salt, pw_hash, joined) values ($1,$2,$3,$4,$5) returning *', [email, name, salt, hash, now]))[0]; }
      catch (e) { return reply(409, { error: 'That email or display name is already taken.' }); }
      const token = await newSession(row.id);
      return reply(201, { user: await pubUser(row), token });
    }

    if (method === 'POST' && path === '/api/login') {
      if (await limited('auth', 10, 60000)) return reply(429, { error: 'Too many attempts. Wait a minute and try again.' });
      const d = await body();
      const email = String(d.email || '').trim().toLowerCase(), pw = typeof d.password === 'string' && d.password.length <= 200 ? d.password : '';
      const u = (await q('select * from users where email = $1', [email]))[0];
      const good = !!u && pw !== '' && same(await pbkdf2(pw, u.pw_salt), u.pw_hash);
      if (!good) return reply(401, { error: 'Wrong email or password.' });
      return reply(200, { user: await pubUser(u), token: await newSession(u.id) });
    }

    if (method === 'POST' && path === '/api/logout') {
      const t = bearer(); if (t) await q('delete from sessions where token_hash = $1', [await sha256(t)]);
      return reply(200, { ok: true });
    }

    if (method === 'GET' && path === '/api/me') { const u = await me(); return reply(200, { user: u ? await pubUser(u) : null }); }

    if (method === 'GET' && path === '/api/my-pastes') {
      const u = await me(); if (!u) return reply(401, { error: 'Sign in to see your pastes.' });
      const rows = await q(`select ${LIST_COLS} from pastes p where p.owner = $2 and ${LIVE} order by p.created_at desc limit 200`, [now, u.id]);
      return reply(200, await summarize(rows));
    }

    if (method === 'DELETE' && path.indexOf('/api/paste/') === 0) {
      const id = decodeURIComponent(path.slice(11)), u = await me();
      const r = u ? await q('delete from pastes where id = $1 and owner = $2 returning id', [id, u.id]) : [];
      if (!r.length) return reply(403, { error: 'Forbidden.' });
      return reply(200, { ok: true });
    }

    if (method === 'POST' && path === '/api/forgot') {
      if (await limited('auth', 10, 60000)) return reply(429, { error: 'Too many requests. Wait a minute and try again.' });
      const d = await body();
      const email = String(d.email || '').trim().toLowerCase();
      if (email.length > 254 || !EMAIL_RE.test(email)) return reply(400, { error: 'Enter a valid email address.' });
      const u = (await q('select * from users where email = $1', [email]))[0];
      if (u) {
        const tok = randHex(24);
        await q("delete from tokens where user_id = $1 and kind = 'reset'", [u.id]);
        await q("insert into tokens (token_hash, kind, user_id, expires_at) values ($1, 'reset', $2, $3)", [await sha256(tok), u.id, now + 3600000]);
        await sendMail(u.email, 'Reset your Paste password', 'Open this link to choose a new password (valid for 1 hour):\n\n' + siteBase() + '/reset?token=' + tok + '\n\nIf you did not ask for this, ignore this email.');
      }
      return reply(200, { ok: true });
    }

    const findToken = async (tok, kind) => {
      if (typeof tok !== 'string' || !/^[A-Za-z0-9]{20,100}$/.test(tok)) return null;
      return (await q('select * from tokens where token_hash = $1 and kind = $2 and expires_at > $3', [await sha256(tok), kind, now]))[0] || null;
    };
    if (method === 'POST' && path === '/api/reset-check') {
      const d = await body();
      return reply(200, { valid: !!(await findToken(d.token, 'reset')) });
    }
    if (method === 'POST' && path === '/api/reset') {
      const d = await body();
      const pw = typeof d.password === 'string' ? d.password : '';
      if (pw.length < 8 || pw.length > 200) return reply(400, { error: PWERR });
      const t = await findToken(d.token, 'reset');
      if (!t) return reply(400, { error: 'This link is not valid any more. Ask for a new one.' });
      const salt = randHex(16);
      await q('update users set pw_salt = $1, pw_hash = $2 where id = $3', [salt, await pbkdf2(pw, salt), t.user_id]);
      await q('delete from tokens where user_id = $1', [t.user_id]);
      await q('delete from sessions where user_id = $1', [t.user_id]);
      return reply(200, { ok: true });
    }

    if (method === 'POST' && path === '/api/change-password') {
      const u = await me(); if (!u) return reply(401, { error: 'Sign in first.' });
      const d = await body();
      if (typeof d.current !== 'string' || !same(await pbkdf2(d.current.slice(0, 200), u.pw_salt), u.pw_hash)) return reply(403, { error: 'Your current password is not right.' });
      const pw = typeof d.password === 'string' ? d.password : '';
      if (pw.length < 8 || pw.length > 200) return reply(400, { error: 'New password must be 8 to 200 characters.' });
      const salt = randHex(16);
      await q('update users set pw_salt = $1, pw_hash = $2 where id = $3', [salt, await pbkdf2(pw, salt), u.id]);
      return reply(200, { ok: true });
    }

    if (method === 'POST' && path === '/api/change-email') {
      const u = await me(); if (!u) return reply(401, { error: 'Sign in first.' });
      const d = await body();
      const ne = String(d.email || '').trim().toLowerCase();
      if (typeof d.password !== 'string' || !same(await pbkdf2(d.password.slice(0, 200), u.pw_salt), u.pw_hash)) return reply(403, { error: 'Your password is not right.' });
      if (ne.length > 254 || !EMAIL_RE.test(ne)) return reply(400, { error: 'Enter a valid email address.' });
      if (ne === u.email) return reply(400, { error: 'That is already your email.' });
      if ((await q('select 1 from users where email = $1', [ne])).length) return reply(409, { error: 'That email already belongs to another account.' });
      const tok = randHex(24);
      await q("delete from tokens where user_id = $1 and kind = 'email'", [u.id]);
      await q("insert into tokens (token_hash, kind, user_id, new_email, expires_at) values ($1, 'email', $2, $3, $4)", [await sha256(tok), u.id, ne, now + 86400000]);
      await sendMail(ne, 'Confirm your new Paste email', 'Open this link to confirm this email address for your Paste account:\n\n' + siteBase() + '/confirm-email?token=' + tok);
      return reply(200, { ok: true });
    }
    if (method === 'POST' && path === '/api/confirm-email') {
      const d = await body();
      const t = await findToken(d.token, 'email');
      if (!t || (await q('select 1 from users where email = $1', [t.new_email])).length) return reply(400, { error: 'This link is not valid any more. Ask for a new one from Settings.' });
      await q('update users set email = $1 where id = $2', [t.new_email, t.user_id]);
      await q('delete from tokens where token_hash = $1', [t.token_hash]);
      return reply(200, { ok: true, email: t.new_email });
    }

    if (method === 'POST' && path === '/api/upload') {
      const u = await me(); if (!u) return reply(401, { error: 'Sign in to upload a photo.' });
      const kind = url.searchParams.get('kind') === 'cover' ? 'cover' : 'avatar';
      const buf = new Uint8Array(await req.arrayBuffer());
      const head = buf.subarray(0, 12); let type = null, ext = '';
      if (head[0] === 0x89 && head[1] === 0x50 && head[2] === 0x4e && head[3] === 0x47) { type = 'image/png'; ext = 'png'; }
      else if (head[0] === 0xff && head[1] === 0xd8 && head[2] === 0xff) { type = 'image/jpeg'; ext = 'jpg'; }
      else if (head[0] === 0x47 && head[1] === 0x49 && head[2] === 0x46 && head[3] === 0x38) { type = 'image/gif'; ext = 'gif'; }
      else if (head[0] === 0x52 && head[1] === 0x49 && head[2] === 0x46 && head[3] === 0x46 && head[8] === 0x57 && head[9] === 0x45) { type = 'image/webp'; ext = 'webp'; }
      if (!type) return reply(400, { error: 'Use a PNG, JPG, GIF or WebP photo.' });
      const cap = kind === 'cover' ? 5 : 2, gifCap = kind === 'cover' ? 20 : 10, lim = type === 'image/gif' ? gifCap : cap;
      if (buf.length > lim * 1048576) return reply(413, { error: 'That photo is too big. The limit is ' + lim + ' MB.' });
      if (buf.length > 1400000) return reply(413, { error: 'That photo is too big. The limit is 1.4 MB.' });
      const key = u.id + '-' + kind + '-' + rid(12) + '.' + ext;
      return reply(201, { path: await ctx.putMedia(key, type, buf) });
    }

    if (method === 'POST' && path === '/api/profile') {
      const u = await me(); if (!u) return reply(401, { error: 'Sign in first.' });
      const d = await body();
      const av = httpsUrl(d.avatar), cv = httpsUrl(d.cover), wb = httpsUrl(d.website);
      if (av === null) return reply(400, { error: 'Profile picture must be a full https:// address.' });
      if (cv === null) return reply(400, { error: 'Cover image must be a full https:// address.' });
      if (wb === null) return reply(400, { error: 'Website must be a full https:// address.' });
      let tg = String(d.telegram || '').trim();
      if (tg) {
        if (/^@?[A-Za-z0-9_]{5,32}$/.test(tg)) tg = 'https://t.me/' + tg.replace(/^@/, '');
        else { const tu = httpsUrl(tg); let ok = false; try { const tx = new URL(tu); ok = ['t.me', 'telegram.me', 'telegram.dog'].indexOf(tx.hostname) >= 0 && tx.pathname.length > 1; } catch (e) { /* invalid */ } if (!ok) return reply(400, { error: 'Telegram must be a link like https://t.me/yourname, or a username like @yourname.' }); tg = tu; }
      }
      let dc = String(d.discord || '').trim();
      if (dc) { dc = httpsUrl(dc); if (!dc || !/^https:\/\/(discord\.gg|discord\.com\/invite)\/[A-Za-z0-9-]+$/.test(dc)) return reply(400, { error: 'Discord must be a discord.gg or discord.com/invite link.' }); }
      const bio = Array.from(String(d.bio || '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '')).slice(0, 300).join('');
      const row = (await q('update users set avatar=$1, cover=$2, bio=$3, telegram=$4, discord=$5, website=$6 where id=$7 returning *', [av, cv, bio, tg, dc || '', wb, u.id]))[0];
      return reply(200, { user: await pubUser(row) });
    }

    if (method === 'GET' && path.indexOf('/api/user/') === 0) {
      const name = decodeURIComponent(path.slice(10));
      const u = (await q('select * from users where lower(name) = lower($1)', [name]))[0];
      if (!u) return reply(404, { error: 'No such member.' });
      const rk = await ranks([u.name]);
      const rows = await q(`select ${LIST_COLS} from pastes p where p.owner = $2 and p.visibility = 'public' and ${LIVE} order by p.created_at desc limit 50`, [now, u.id]);
      return reply(200, { name: u.name, joined: u.joined || now, profile: profileOf(u), rank: brief(rk[u.name.toLowerCase()]), pastes: await summarize(rows) });
    }

    if (method === 'POST' && path === '/api/pin') {
      const u = await me(); if (!u) return reply(403, { error: 'Only the site owner can pin pastes.' });
      const d = await body();
      const p = (await q(`select p.* from pastes p where p.id = $2 and ${LIVE}`, [now, String(d.id)]))[0];
      if (!p) return reply(404, { error: 'Paste not found or expired.' });
      if (p.owner !== u.id) return reply(403, { error: 'You can pin your own pastes.' });
      if (d.pinned === true) {
        if (p.visibility !== 'public') return reply(400, { error: 'Only public pastes can be pinned.' });
        const c = (await q(`select count(*)::int c from pastes p where p.pinned and ${LIVE}`, [now]))[0].c;
        if (!p.pinned && c >= 5) return reply(400, { error: 'You can pin up to 5 pastes. Unpin one first.' });
        if (!p.pinned) await q('update pastes set pinned = true, pinned_at = $1 where id = $2', [now, p.id]);
        return reply(200, { ok: true, pinned: true });
      }
      await q('update pastes set pinned = false, pinned_at = null where id = $1', [p.id]);
      return reply(200, { ok: true, pinned: false });
    }

    if (method === 'POST' && path === '/api/vote') {
      const u = await me(); if (!u) return reply(401, { error: 'Sign in to like or dislike a paste.' });
      const d = await body();
      const p = (await q(`select p.id from pastes p where p.id = $2 and ${LIVE}`, [now, String(d.id)]))[0];
      if (!p) return reply(404, { error: 'Paste not found or expired.' });
      const v = d.v === 1 ? 1 : d.v === -1 ? -1 : 0;
      if (v === 0) await q('delete from votes where paste_id = $1 and user_id = $2', [p.id, u.id]);
      else await q('insert into votes (paste_id, user_id, v) values ($1,$2,$3) on conflict (paste_id, user_id) do update set v = excluded.v', [p.id, u.id, v]);
      const c = (await q('select count(*) filter (where v = 1)::int up, count(*) filter (where v = -1)::int down from votes where paste_id = $1', [p.id]))[0];
      return reply(200, { up: c.up, down: c.down, vote: v });
    }

    if (method === 'POST' && path === '/api/report') {
      if (await limited('report', 10, 60000)) return reply(429, { error: 'Too many reports. Wait a minute and try again.' });
      const d = await body();
      const p = (await q('select id from pastes where id = $1', [String(d.id)]))[0];
      if (!p) return reply(404, { error: 'Paste not found.' });
      await q('insert into reports (paste_id, reason, created_at) values ($1, $2, $3)', [p.id, String(d.reason || '').slice(0, 500), now]);
      return reply(200, { ok: true });
    }

    if ((method === 'GET' || (method === 'POST' && /\/open$/.test(path))) && path.indexOf('/api/paste/') === 0) {
      const id = decodeURIComponent(path.slice(11).replace(/\/open$/, ''));
      const p = (await q(`select p.* from pastes p where p.id = $2 and ${LIVE}`, [now, id]))[0];
      if (!p) return reply(404, { error: 'Paste not found or expired.' });
      const u = await me();
      const own = !!(u && p.owner && p.owner === u.id);
      const locked = !!p.pw_hash && !own;
      if (locked) {
        if (method === 'GET') return reply(200, { locked: true, id: p.id });
        const d = await body();
        if (typeof d.password !== 'string' || !same(await pbkdf2(d.password.slice(0, 200), p.pw_salt), p.pw_hash)) return reply(403, { error: 'Wrong password.' });
      }
      const views = (await q('update pastes set views = views + 1 where id = $1 returning views', [p.id]))[0].views;
      const c = (await q('select count(*) filter (where v = 1)::int up, count(*) filter (where v = -1)::int down from votes where paste_id = $1', [p.id]))[0];
      const mv = u ? (await q('select v from votes where paste_id = $1 and user_id = $2', [p.id, u.id]))[0] : null;
      let by = null;
      if (p.owner) { const au = (await q('select * from users where id = $1', [p.owner]))[0]; if (au) { const rk = await ranks([au.name]); by = { name: au.name, joined: au.joined || 0, profile: profileOf(au), rank: brief(rk[au.name.toLowerCase()]) }; } }
      const out = { id: p.id, title: p.title, author: p.author || '', content: p.content, syntax: p.syntax, visibility: p.visibility, size: p.size, views, createdAt: p.created_at, expiresAt: p.expires_at, protected: !!p.pw_hash, mine: own, up: c.up, down: c.down, vote: mv ? mv.v : 0, by };
      if (p.pinned) { out.pinned = true; out.pinnedAt = p.pinned_at; }
      return reply(200, out);
    }

    const ORDER_PIN = 'p.pinned desc, case when p.pinned then p.pinned_at end desc nulls last';
    // ---- community chat ----
    if (path === '/api/chat' && method === 'GET') {
      const after = Math.max(0, parseInt(url.searchParams.get('after') || '0', 10) || 0);
      const rows = after
        ? await q('select m.id, m.body, m.created_at, m.user_id, u.name, u.avatar from chat_messages m join users u on u.id = m.user_id where m.id > $1 order by m.id asc limit 100', [after])
        : (await q('select m.id, m.body, m.created_at, m.user_id, u.name, u.avatar from chat_messages m join users u on u.id = m.user_id order by m.id desc limit 60')).reverse();
      const rk = await ranks(rows.map((r) => r.name));
      const u = await me();
      return reply(200, { messages: rows.map((r) => ({ id: Number(r.id), text: r.body, at: r.created_at, name: r.name, avatar: r.avatar || '', mine: !!u && u.id === r.user_id, rank: brief(rk[r.name.toLowerCase()]) })) });
    }
    if (path === '/api/chat' && method === 'POST') {
      const u = await me(); if (!u) return reply(401, { error: 'Join or sign in to chat.' });
      if (await limited('chat', 12, 30000)) return reply(429, { error: 'Slow down a little.' });
      const d = await body();
      const c = chatCheck(d.text); if (c.error) return reply(400, { error: c.error });
      const last = (await q('select body, created_at from chat_messages where user_id = $1 order by id desc limit 1', [u.id]))[0];
      if (last && now - last.created_at < 1500) return reply(429, { error: 'Slow down a little.' });
      if (last && last.body === c.text && now - last.created_at < 60000) return reply(400, { error: 'You already sent that.' });
      const r = await q('insert into chat_messages (user_id, body, created_at) values ($1, $2, $3) returning id', [u.id, c.text, now]);
      await q('delete from chat_messages where id < $1', [Number(r[0].id) - 500]);
      return reply(201, { id: Number(r[0].id) });
    }
    if (method === 'DELETE' && path.startsWith('/api/chat/')) {
      const u = await me(); if (!u) return reply(401, { error: 'Sign in first.' });
      const id = parseInt(path.slice(10), 10); if (!id) return reply(404, { error: 'Not found.' });
      await q('delete from chat_messages where id = $1 and user_id = $2', [id, u.id]);
      return reply(200, { ok: true });
    }

    if (method === 'GET' && path === '/api/recent') {
      const rows = await q(`select ${LIST_COLS} from pastes p where p.visibility = 'public' and ${LIVE} order by ${ORDER_PIN}, p.created_at desc limit 50`, [now]);
      return reply(200, await summarize(rows));
    }
    if (method === 'GET' && path === '/api/top') {
      const rows = await q(`select ${LIST_COLS} from pastes p where p.visibility = 'public' and ${LIVE} order by ${ORDER_PIN}, p.views desc, p.created_at desc limit 50`, [now]);
      return reply(200, await summarize(rows));
    }
    if (method === 'GET' && path === '/api/search') {
      const term = (url.searchParams.get('q') || '').trim().toLowerCase().slice(0, 100);
      if (!term) return reply(200, []);
      const rows = await q(`select ${LIST_COLS} from pastes p where p.visibility = 'public' and ${LIVE} and (position($2 in lower(p.title)) > 0 or position($2 in lower(p.content)) > 0) order by p.created_at desc limit 50`, [now, term]);
      return reply(200, await summarize(rows));
    }
    return reply(404, { error: 'Not found.', v: 'v3', seen: url.pathname });
  } catch (e) {
    if (e && e.code && typeof e.code === 'number') return reply(e.code, { error: e.message });
    console.error(e);
    return reply(500, { error: 'Something went wrong on the server. Try again.' });
  }
}


// ---- Cloudflare D1 adapter (translates the Postgres-style queries to SQLite) ----
const SCHEMA = [
`create table if not exists users (id text primary key default (lower(hex(randomblob(16)))), email text not null unique, name text not null, pw_salt text not null, pw_hash text not null, joined real not null, avatar text not null default '', cover text not null default '', bio text not null default '', telegram text not null default '', discord text not null default '', website text not null default '')`,
`create unique index if not exists users_name_lower on users (lower(name))`,
`create table if not exists sessions (token_hash text primary key, user_id text not null references users(id) on delete cascade, created_at real not null, expires_at real not null)`,
`create index if not exists sessions_user on sessions (user_id)`,
`create table if not exists pastes (id text primary key, title text not null, author text not null default '', owner text references users(id) on delete set null, content text not null, syntax text not null default 'none', visibility text not null default 'public', size integer not null, views integer not null default 0, created_at real not null, expires_at real, pw_salt text, pw_hash text, pinned integer not null default 0, pinned_at real)`,
`create index if not exists pastes_recent on pastes (created_at)`,
`create index if not exists pastes_top on pastes (views)`,
`create index if not exists pastes_owner on pastes (owner)`,
`create table if not exists votes (paste_id text not null references pastes(id) on delete cascade, user_id text not null references users(id) on delete cascade, v integer not null check (v in (-1, 1)), primary key (paste_id, user_id))`,
`create table if not exists reports (id integer primary key autoincrement, paste_id text not null, reason text not null default '', created_at real not null)`,
`create table if not exists tokens (token_hash text primary key, kind text not null, user_id text not null references users(id) on delete cascade, new_email text, expires_at real not null)`,
`create table if not exists rate_events (k text not null, t real not null)`,
`create index if not exists rate_k on rate_events (k, t)`,
`create table if not exists chat_messages (id integer primary key autoincrement, user_id text not null references users(id) on delete cascade, body text not null, created_at real not null)`,
`create table if not exists media (k text primary key, type text not null, data text not null, created_at real not null)`
];
function toSqlite(text) {
  let s = text.replace(/\$(\d+)/g, '?$1').replace(/::int\b/g, '');
  s = s.replace(/position\(\?(\d+) in ([^)]+\))\) > 0/g, 'instr($2, ?$1) > 0');
  if (/^\s*delete from pastes p where/i.test(s)) s = s.replace(/delete from pastes p where/i, 'delete from pastes where').replace(/\bp\./g, '');
  return s;
}
function makeQ(db) {
  return async function q(text, params) {
    const args = (params || []).map((v) => v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : v);
    const r = await db.prepare(toSqlite(text)).bind(...args).all();
    return r.results || [];
  };
}
let schemaReady = null;
async function ensureSchema(db) {
  if (!schemaReady) schemaReady = db.batch(SCHEMA.map((s) => db.prepare(s))).catch((e) => { schemaReady = null; throw e; });
  return schemaReady;
}

// ---- Cloudflare Pages entry ----
const b64 = (u8) => { let s = ''; for (let i = 0; i < u8.length; i += 8192) s += String.fromCharCode.apply(null, u8.subarray(i, i + 8192)); return btoa(s); };
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/media/')) {
      if (!env.DB) return new Response(JSON.stringify({ error: 'Database not connected. In Cloudflare: Settings > Bindings > add D1 database with the variable name DB, then redeploy.' }), { status: 500, headers: { 'Content-Type': 'application/json' } });
      try { await ensureSchema(env.DB); } catch (e) { return new Response(JSON.stringify({ error: 'Database setup failed: ' + String(e && e.message || e).slice(0, 160) }), { status: 500, headers: { 'Content-Type': 'application/json' } }); }
    }
    if (url.pathname.startsWith('/media/')) {
      const row = await env.DB.prepare('select type, data from media where k = ?1').bind(url.pathname.slice(7)).first();
      if (!row) return new Response('Not found', { status: 404 });
      const bin = atob(row.data), u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      return new Response(u8, { headers: { 'Content-Type': row.type, 'Cache-Control': 'public, max-age=31536000, immutable', 'X-Content-Type-Options': 'nosniff' } });
    }
    if (url.pathname.startsWith('/api/')) {
      return handle(request, {
        q: makeQ(env.DB), iterations: 40000,
        env: { RESEND_API_KEY: env.RESEND_API_KEY, MAIL_FROM: env.MAIL_FROM, SITE_URL: env.SITE_URL || url.origin },
        putMedia: async (key, type, u8) => { await env.DB.prepare('insert or replace into media (k, type, data, created_at) values (?1, ?2, ?3, ?4)').bind(key, type, b64(u8), Date.now()).run(); return url.origin + '/media/' + key; }
      });
    }
    let res = await env.ASSETS.fetch(request);
    if (res.status === 404 && (request.method === 'GET' || request.method === 'HEAD') && !/\.[a-z0-9]{2,5}$/i.test(url.pathname)) res = await env.ASSETS.fetch(new Request(new URL('/index.html', url), request));
    return res;
  }
};
